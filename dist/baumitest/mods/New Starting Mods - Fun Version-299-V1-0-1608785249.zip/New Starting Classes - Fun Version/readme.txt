Drag Folders 'msg' 'Param' and 'Paramdef' into Dark Souls Remastered directory and overwrite when asked.

If you dont want this mod anymore, just verify integerity of steam files.